BACKROOMS IRIS 1.0
Open-source co-op Backrooms horror. MIT license.

RUN
  Windows: double-click backrooms-iris.exe (keep SDL2.dll next to it).
  Linux:   ./backrooms-iris   (needs SDL2 + OpenGL; on Arch: sudo pacman -S sdl2-compat mesa)

PLAY TOGETHER (up to 4, no servers)
  One player: MULTIPLAYER > HOST GAME (optionally set a password) > START HOSTING.
  Everyone else: MULTIPLAYER > JOIN GAME. Pick the game from the list, or type the host's address.
    Same Wi-Fi/LAN ...... it shows up in the list
    Tailscale ........... install it on every PC, same tailnet: it shows up in the list
    Port forwarding ..... host forwards UDP 27315 to their PC; friends type the host's public IP
                          (set a password if you do this)

CONTROLS
  WASD move, mouse look, Shift sprint, Ctrl/C crouch, E pick up, left click/Q use item,
  1-9 / wheel pick item, F flashlight, Tab sandbox menu, Esc pause, F12 screenshot, F11 fullscreen.
  Gamepads work too.

Source, docs and the PS Vita build: see the project's GitHub page.
